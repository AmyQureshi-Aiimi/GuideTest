﻿using InsightMaker.Core.Types;

[assembly: log4net.Config.XmlConfigurator(ConfigFile = "log4net.config")]

namespace InsightMaker.Enrichment.HelloWorldES.Test
{
    class Program
    {
        protected static readonly log4net.ILog log = 
            log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        static void Main(string[] args)
        {
            log.Info("InsightMaker.Enrichment.HelloWorldES.Test");
 
            var workItem = new EnrichmentWorkItem(new IndexedFile
            {
                Uri = "does not matter for testing",
                TextContent = "This is our documents text content."
            });

            var helloWorldESConfiguration = new HelloWorldESConfiguration();
            helloWorldESConfiguration.HelloWorldES.Text = "Hello World";

            var helloWorldESFactory = new HelloWorldESFactory();
            var helloWorldESStep = (HelloWorldESStep)helloWorldESFactory.BuildEnrichmentStep(helloWorldESConfiguration, 
                                                                                             new System.Threading.CancellationToken());

            try
            {
                Console.WriteLine("Before: " + workItem.File.TextContent);
                helloWorldESStep.Run(workItem);
                Console.WriteLine("After: " + workItem.File.TextContent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
            }
        }
    }
}

