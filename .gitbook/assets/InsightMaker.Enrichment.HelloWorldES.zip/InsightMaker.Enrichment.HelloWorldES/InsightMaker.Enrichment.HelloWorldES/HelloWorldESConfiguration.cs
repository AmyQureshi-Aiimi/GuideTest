﻿using InsightMaker.Core.Types.Config;

namespace InsightMaker.Enrichment.HelloWorldES
{
    public class HelloWorldESConfiguration : EnrichmentStepConfiguration
    {
        public HelloWorldESConfiguration()
        {
            base.Type = "HelloWorldES";
        }

        public HelloWorldESSpecificConfiguration HelloWorldES { get; set; } 
            = new HelloWorldESSpecificConfiguration();
    }

    public class HelloWorldESSpecificConfiguration
    {
        public string Text { get; set; } = "";
    }
}
