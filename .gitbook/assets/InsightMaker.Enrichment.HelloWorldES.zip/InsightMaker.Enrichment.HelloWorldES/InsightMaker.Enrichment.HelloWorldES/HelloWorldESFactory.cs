﻿using InsightMaker.Core.Types.Plugin;
using InsightMaker.Core.Types;
using InsightMaker.Core.Types.Config;
using System.ComponentModel.Composition;

namespace InsightMaker.Enrichment.HelloWorldES
{
    [Export(typeof(IEnrichmentStepFactory))]
    [ExportMetadata("Type", "HelloWorldES")]
    [ExportMetadata("Description", "Hello World Enrichment Step")]
    [ExportMetadata("DisplayName", "HelloWorldES")]
    [ExportMetadata("Chargeable", false)]
    [ExportMetadata("ConfigurationType", typeof(HelloWorldESConfiguration))]
    [ExportMetadata("StepGroup", StepGroup.Entities)]
    [ExportMetadata("DisplayOrder", 40)]
    [ExportMetadata("Inputs", EnrichmentStepDataType.Text)]
    [ExportMetadata("Outputs", EnrichmentStepDataType.Text)]
    [ExportMetadata("ThirdParty", Dependency.None)]
    public class HelloWorldESFactory : IEnrichmentStepFactory
    {
        public IEnrichmentStep BuildEnrichmentStep(EnrichmentStepConfiguration configuration, 
                                                   CancellationToken cancellationToken)
        {
            return new HelloWorldESStep((HelloWorldESConfiguration)configuration, 
                                        cancellationToken);
        }

        public object GetDefaultConfiguration()
        {
            return new HelloWorldESConfiguration();
        }
    }
}
