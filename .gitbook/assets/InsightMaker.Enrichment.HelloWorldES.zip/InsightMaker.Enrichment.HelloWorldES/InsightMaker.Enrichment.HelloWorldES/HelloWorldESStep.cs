﻿using InsightMaker.Core.Types;

namespace InsightMaker.Enrichment.HelloWorldES
{
    public class HelloWorldESStep : IEnrichmentStep
    {
        protected static readonly log4net.ILog log = 
            log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private HelloWorldESConfiguration configuration;
        private CancellationToken cancellationToken;

        public HelloWorldESStep(HelloWorldESConfiguration configuration, 
                                CancellationToken token)
        {
            this.configuration = configuration;
            this.cancellationToken = token;
        }

        public void Run(EnrichmentWorkItem work)
        {
            work.File.TextContent += " " + configuration.HelloWorldES.Text;
        }
    }
}
